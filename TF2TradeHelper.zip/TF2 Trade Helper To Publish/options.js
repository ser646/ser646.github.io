function save_options() {
  var dtf = document.getElementById("dynamic_item_transfer_checkbox").checked;
  var steamid = document.getElementsByClassName("steamid_input")[0].value;
  var reversed_adding = document.getElementById("reversed_adding_checkbox").checked;
  var apikey = document.getElementById("apikey_input").value;
  chrome.storage.sync.set({
    dtf: dtf,
    reversed_adding: reversed_adding,
    steamid: steamid,
    apikey: apikey
  }, function () {
    console.log("Saved");
  });
}

function restore_options() {
  chrome.storage.sync.get({
    dtf: true,
    reversed_adding: false,
    steamid: "",
    apikey: ""
  }, function (items) {
    document.getElementsByClassName("steamid_input")[0].value = items.steamid;
    document.getElementById("dynamic_item_transfer_checkbox").checked = items.dtf;
    document.getElementById("reversed_adding_checkbox").checked = items.reversed_adding;
    document.getElementById("apikey_input").value = items.apikey;
  });
}

function checkSteamId() {
  $(".steamid_input").each(function () {
    console.log($(this))
    var steamid = $(this).val();
    $("#steamid_error").css('display', "none");
    steamid = "" + steamid + "";
    if (steamid != '') {
      if (steamid.slice(0, 7) != '7656119' || steamid.length != 17) { $("#steamid_error").css('display', "block"); return false; }
      else if (steamid.slice(0, 7) == '7656119' || steamid.length == 17) { save_options(); return true; }
    }
    else save_options();
  })
}

$(".steamid_input").on('change', checkSteamId);
$("#apikey_input").on('change', save_options);
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById("dynamic_item_transfer_checkbox").onclick = save_options;
document.getElementById("reversed_adding_checkbox").onclick = save_options;
var steamid = g_rgProfileData.steamid;

function SendMessage(data) {
	var message = { data };
	console.log("Sent:", message);
	var event = new CustomEvent("FromInjected", { detail: message });
	window.dispatchEvent(event);
}

SendMessage(steamid);
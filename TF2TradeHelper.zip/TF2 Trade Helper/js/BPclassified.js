function setURLParameter(url, key, value) {
    var l_url = url.split('&'), query = {}, new_url = "";
    //console.log(url_list);
    for (var i = 0; i < l_url.length; i++) {
        if (l_url[i].indexOf('=') !== -1) {
            var param = l_url[i].split('=');
            query[param[0]] = param[1];
            //console.log(param);
        } else if (i !== l_url.length - 1) {
            new_url += str + "&";
        }
    }
    query[key] = value; //sets new query
    new_url += $.param(query);
    new_url = decodeURIComponent(new_url);
    //console.log(new_url);
    return new_url;
}


function getItemData(ele) {
    var data = ele.parentElement.parentElement.parentElement.firstElementChild.firstElementChild.firstElementChild.children[0].dataset

    var price = data.listing_price;
    var arr = price.split(',');
    var key = '', ref = '';
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].indexOf("key") > -1) {
            key = arr[i].match(/[\d\.]+/)[0];
        } else if (arr[i].indexOf("ref") > -1) {
            ref = arr[i].match(/[\d\.]+/)[0];
        }
    }
    if (key) ele.href = setURLParameter(ele.href, "key", key);
    if (ref) ele.href = setURLParameter(ele.href, "ref", ref);

    ele.href = setURLParameter(ele.href, "def_index", data.defindex);
    ele.href = setURLParameter(ele.href, "quality", data.quality);
    ele.href = setURLParameter(ele.href, "amount", ele.parentElement.lastChild.value);
}

//document.getElementsByClassName("btn btn-bottom btn-xs btn-success")[0].addEventListener("click", "getItemData(this)")

var parent = document.getElementsByClassName("pull-right listing-buttons");

for (var i = 0; i < parent.length; i++) {
    var ele = document.createElement("input");
    ele.type = "number";
    ele.min = "0";
    ele.placeholder = 0;
    ele.style = "width: 40px;border-radius: .5em .5em 0 0;height: 22px;border-style: solid;border-width: 1px;float: inherit;background-color: white;border-color: #547824;text-align: end;";
    parent[i].appendChild(ele);
    parent[i].children[1].setAttribute('onclick', "getItemData(this)")
}
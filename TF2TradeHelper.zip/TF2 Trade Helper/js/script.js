var MyInv;
var TheirInv;
var MyInv_Full;
var TheirInv_Full;
var reverse = true;
var who;
var inv;

//Receive messages
window.addEventListener("ToInjected", function (evt) {
    reverse = evt.detail[0];
    console.log("Received: ", evt.detail);
}, false);

//Send messages
function SendMessage(data) {
    var message = { data };
    console.log("Sent:", message);
    var event = new CustomEvent("FromInjected", { detail: message });
    window.dispatchEvent(event);
}

RequestFullInventory(
    g_strTradePartnerInventoryLoadURL,
    { sessionid: g_sessionID, partner: UserYou.strSteamId, appid: 440, contextid: 2 },
    function (transport) {
        MyInv = Object.values(transport.responseJSON.rgInventory);
        MyInv.sort(function (a, b) { return a.pos - b.pos });
        MyInv_Full = JSON.parse(JSON.stringify(MyInv));
        if (TheirInv) { UpdateMetalValue(); createObservers(); addAssetsFromUrl() }
    },
    null,
    null
)
RequestFullInventory(
    g_strTradePartnerInventoryLoadURL,
    { sessionid: g_sessionID, partner: UserThem.strSteamId, appid: 440, contextid: 2 },
    function (transport) {
        TheirInv = Object.values(transport.responseJSON.rgInventory);
        TheirInv.sort(function (a, b) { return a.pos - b.pos });
        TheirInv_Full = JSON.parse(JSON.stringify(TheirInv));
        if (MyInv) { UpdateMetalValue(); createObservers(); addAssetsFromUrl() }
    },
    null,
    null
)

// Added updateTrade to stock steam functions:
function MoveItemToInventory(elItem) {
    var item = elItem.rgItem;
    if (BIsInTradeSlot(elItem)) { CleanupSlot(elItem.parentNode.parentNode); }
    if (item.is_stackable) {
        SetStackableItemInTrade(item, 0);
        return;
    }
    RevertItem(item);
    item.homeElement.down('.slot_actionmenu_button').show();
    GTradeStateManager.RemoveItemFromTrade(item);



    updateTrade();
}
function MoveItemToTrade(elItem) {
    var item = elItem.rgItem;
    if (item.is_stackable) { ShowStackableItemDialog(elItem); }
    else { FindSlotAndSetItem(item); }



    updateTrade();
}

document.getElementById("add_keys").setAttribute("onclick", "{ Inv_Who(); AddKeys() }");
document.getElementById("add_metal").setAttribute("onclick", "{ Inv_Who(); AddMetal() }");

function Inv_Who(elItem) {
    if (elItem) {
        if (UserYou.strProfileURL.split("/")[4] == elItem.firstChild.href.split("/")[4]) { inv = MyInv; who = g_rgCurrentTradeStatus.me }
        else { inv = TheirInv; who = g_rgCurrentTradeStatus.them }
    }
    else {
        if (g_ActiveUser.strProfileURL == UserYou.strProfileURL) { inv = MyInv; who = g_rgCurrentTradeStatus.me }
        else { inv = TheirInv; who = g_rgCurrentTradeStatus.them }
    }
}

function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

function addAssetsFromUrl() {
    var amount = getUrlParameter("amount");

    if (getUrlParameter("amount")) {

        var classid;
        var def_index = getUrlParameter("def_index");
        var quality = getUrlParameter("quality");

        var key = getUrlParameter("key");
        var ref = getUrlParameter("ref");
        if (!getUrlParameter("for_item")) {
            classid = MyInv.find(item => item.app_data.def_index == def_index && item.app_data.quality == quality).classid;
            manageItemsInTrade(who, createStackByClassID(classid, amount, inv, reverse), 'add')
            inv = TheirInv;
            who = g_rgCurrentTradeStatus.them;
            if (key) AddKeys(key * amount);
            if (ref) AddMetal(calcMetal(amount, ref, '*'));
        }
        else {
            if (key) AddKeys(key * amount);
            if (ref) AddMetal(calcMetal(amount, ref, '*'));
            inv = TheirInv;
            who = g_rgCurrentTradeStatus.them;
            classid = MyInv.find(item => item.app_data.def_index == def_index && item.app_data.quality == quality).classid;
            manageItemsInTrade(who, createStackByClassID(classid, amount, inv, reverse), 'add')
        }
    }
}

/* Observers */
function createObservers() {

    function InventoryMutation() { UpdateMetalValue(); }

    var inventory_observer = new MutationObserver(InventoryMutation)

    var observer_cfg = { subtree: true, childList: true }
    inventory_observer.observe(document.getElementById('inventories'), observer_cfg)

    document.getElementsByClassName("inventory_user_tab")[0].addEventListener('click', function () {
        document.getElementById("keys_input").value = "";
        document.getElementById("metal_input").value = "";
        UpdateMetalValue();
    });
    document.getElementsByClassName("inventory_user_tab")[1].addEventListener('click', function () {
        document.getElementById("keys_input").value = "";
        document.getElementById("metal_input").value = "";
        UpdateMetalValue();
    });
}

document.getElementById("keys_input").setAttribute('oninput', 'check_maxInput(this)');
document.getElementById("metal_input").setAttribute('oninput', 'check_maxInput(this)');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////^^^^^Things used only at start^^^^^///////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function ShowHover(elem, item) {
    var hover = $('hover');
    if (hover.target != elem || hover.builtFor != item || hover.builtForAmount != item.amount) {
        if (hover.target) hover.target.removeClassName('hover');
        BuildHover('hover', item);
        hover.target = elem;
    }
    var divHoverContents = hover.down('.hover_box');
    hover.style.visibility = 'hidden';
    hover.show();
    hover.clonePosition(elem, { setWidth: false, setHeight: false });
    var hover_box = hover.down('.hover_box');
    var hover_arrow_left = hover.down('.hover_arrow_left');
    var hover_arrow_right = hover.down('.hover_arrow_right');
    var hover_arrow = hover_arrow_left;
    var nHoverHorizontalPadding = (hover_arrow ? -4 : 8);
    var boxRightViewport = elem.viewportOffset().left + parseInt(elem.getDimensions().width) + hover_box.getWidth() + (24 - nHoverHorizontalPadding);

    var nSpaceRight = document.viewport.getWidth() - boxRightViewport;
    var nSpaceLeft = parseInt(hover.style.left) - hover.getWidth();
    if (boxRightViewport > document.viewport.getWidth() && nSpaceLeft > nSpaceRight) {



        hover.style.left = (parseInt(hover.style.left) - hover.getWidth() - 9 + nHoverHorizontalPadding) + 'px';
        document.getElementById("trade_hover").style.margin = "12px 4px 12px 12px"



        hover_arrow = hover_arrow_right;
    }
    else {



        hover.style.left = (parseInt(hover.style.left) + parseInt(elem.getDimensions().width) + 9 - nHoverHorizontalPadding) + 'px';
        document.getElementById("trade_hover").style.margin = "12px 12px 12px 4px"



    }
    if (hover_arrow) {
        hover_arrow_left.hide();
        hover_arrow_right.hide();
        hover_arrow.show();
    }
    var nTopAdjustment = 0;
    if (elem.getDimensions().height < 98) nTopAdjustment = elem.getDimensions().height / 2 - 49;
    hover.style.top = ((parseInt(hover.style.top) - 13) + nTopAdjustment) + 'px';
    var boxTopViewport = elem.viewportOffset().top + nTopAdjustment;
    if (boxTopViewport + hover_box.getHeight() + 8 > document.viewport.getHeight()) {
        var nViewportAdjustment = (hover_box.getHeight() + 8) - (document.viewport.getHeight() - boxTopViewport);
        nViewportAdjustment = Math.min(hover_box.getHeight() - 74, nViewportAdjustment);
        hover.style.top = (parseInt(hover.style.top) - nViewportAdjustment) + 'px';
        if (hover_arrow) hover_arrow.style.top = (48 + nViewportAdjustment) + 'px';
    }
    else { if (hover_arrow) hover_arrow.style.top = ''; }
    hover.hide();
    hover.style.visibility = '';
    ShowWithFade(hover);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////^^^^^Steam hover over item fix^^^^^///////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function MouseOverItem(event, owner, elItem, rgItem) {
    // no hovers while the user is moving items around
    if (g_bEnableDynamicSizing || (g_bIsTrading && g_bInDrag) || (rgItem.in_touch)) return;
    elItem.addClassName('hover');



    elItem.children[1].lastChild.max = check_amount(elItem);
    elItem.children[1].style.display = "block";
    if (BIsInTradeSlot(elItem)) {
        elItem.children[1].firstChild.setAttribute("onclick", "ToInventory(this.parentElement.parentElement,this.nextSibling.value)")
        elItem.children[1].firstChild.innerText = '─';
        elItem.children[1].firstChild.style = "font-size: 17px;line-height: 2px;";
    }
    else {
        elItem.children[1].firstChild.setAttribute("onclick", "ToTrade(this.parentElement.parentElement,this.nextSibling.value)");
        elItem.children[1].firstChild.innerText = '+';
        elItem.children[1].firstChild.style = "font-size: 22px;line-height: 1px;";
    }



    var hover = $('hover');
    if (hover.hiding && hover.visible() && hover.target == elItem) { ShowWithFade(hover); }
    else if ((!hover.visible() || hover.target != elItem) && !elItem.timer) {
        elItem.wants_hover = true;



        // if the hover is visible, wait a bit to give it a chacne to disappear                        <-----------------LITERÓWKA VOLVO



        if (hover.visible()) window.setTimeout(function () { if (elItem.wants_hover) BuildHover('hover', rgItem, owner); }, Math.min(250, ITEM_HOVER_DELAY - 50));
        else BuildHover('hover', rgItem, owner);
        elItem.timer = window.setTimeout(function () { elItem.timer = false; if (elItem.wants_hover) ShowHover(elItem, rgItem); elItem.wants_hover = false; }, ITEM_HOVER_DELAY);
    }
}

function MouseOutItem(event, owner, elItem, rgItem) {



    elItem.children[1].style.display = "none";



    if (event) {
        var reltarget = (event.relatedTarget) ? event.relatedTarget : event.toElement;
        if (reltarget && (reltarget == elItem || ($(reltarget).up('#' + elItem.identify())))) return;
    }
    CancelItemHover(elItem);
}


CInventory.prototype.BuildItemElement = function (rgItem) {
    var elItem = new Element('div', { id: 'item' + this.appid + '_' + this.contextid + '_' + rgItem.id, 'class': 'item app' + this.appid + ' context' + this.contextid });
    if (rgItem.name_color) elItem.style.borderColor = '#' + rgItem.name_color;
    if (rgItem.background_color) elItem.style.backgroundColor = '#' + rgItem.background_color;
    rgItem.appid = this.appid;
    rgItem.contextid = this.contextid;
    elItem.rgItem = rgItem;
    if (rgItem.is_stackable) elItem.lazyload_image = ImageURL(rgItem.icon_url, '96f', '58f', true);
    else elItem.lazyload_image = ImageURL(rgItem.icon_url, '96f', '96f', true);
    if (typeof (rgItem.icon_drag_url) != 'undefined' && rgItem.icon_drag_url != '') {
        if (rgItem.is_stackable) elItem.drag_image = ImageURL(rgItem.icon_drag_url, '96f', '58f', true);
        else elItem.drag_image = ImageURL(rgItem.icon_drag_url, '96f', '96f', true);
    }
    if (rgItem.is_stackable) {
        var elAmount = new Element('div', { 'class': 'item_currency_amount' });
        if (rgItem.name_color) elAmount.style.color = '#' + rgItem.name_color;
        if (CurrencyIsWalletFunds(rgItem)) elAmount.update(v_currencyformat(rgItem.amount, rgItem.name));
        else elAmount.update(v_numberformat(rgItem.amount));
        elItem.appendChild(elAmount);
        var elCurrencyName = new Element('div', { 'class': 'item_currency_name' });
        if (rgItem.name_color) elCurrencyName.style.color = '#' + rgItem.name_color;
        elCurrencyName.update(rgItem.is_currency ? rgItem.name : '');
        elItem.appendChild(elCurrencyName);
    }
    if (g_bIsTrading) {
        Event.observe(elItem, 'mouseover', MouseOverItem.bindAsEventListener(null, this.owner, elItem, rgItem));
        Event.observe(elItem, 'mouseout', MouseOutItem.bindAsEventListener(null, this.owner, elItem, rgItem));
    }
    var url = (g_bIsTrading ? this.GetInventoryPageURL() : '') + '#' + this.appid + '_' + this.contextid + '_' + rgItem.id;
    var elLink = new Element('a', { href: url, 'class': 'inventory_item_link' });
    if (Prototype.Browser.IE) { elLink.appendChild(new Element('img', { src: 'https://steamcommunity-a.akamaihd.net/public/images/trans.gif', width: 96, height: 96 })); }
    elItem.appendChild(elLink);
    this.BindMouseEvents(elLink, elItem);
    if (rgItem.fraudwarnings) {
        var elFraudWarningIcon = new Element('div', { 'class': 'slot_app_fraudwarning' });
        elItem.appendChild(elFraudWarningIcon);
    }



    var elAmount = new Element('div', { 'class': 'amount_element' })
    elAmount.appendChild(new Element('button', { 'class': 'amount_button' }))
    elAmount.appendChild(new Element('input', { 'class': 'amount_input', 'oninput': 'check_maxInput(this)', 'type': 'number', 'min': '1', 'value': '1' }))
    elItem.appendChild(elAmount);



    return elItem;
}

function OnDoubleClickItem(event, elItem) { }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////^^^^^ amount_element improvements ^^^^^/////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function RemoveSlots(slots, hasItem) {
    var s = Math.ceil(slots.length / 4) * 4;
    var h = Math.ceil((Math.ceil(hasItem.length / 4) * 4) / 4) * 4;
    if (h >= 2) {
        for (var i = 0; i < (s - h); i++) {
            slots[h].remove();
        }
    }
    else {
        for (var j = 0; j < (s / 4); j++) {
            for (var i = 0; i < s - 8; i++) {
                if (slots[8]) slots[8].remove();
            }
        }
    }
}
var FixAfterClear = function () {
    var slots = document.getElementById("trade_yours").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot");
    var hasItem = document.getElementById("trade_yours").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot has_item");
    RemoveSlots(slots, hasItem);
    var slots = document.getElementById("trade_theirs").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot");
    var hasItem = document.getElementById("trade_theirs").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot has_item");
    RemoveSlots(slots, hasItem);
}
/* ^^^^^^Fixing broken inventory page and trade window while removing more than 12 items^^^^^^ */

function calcMetal(in1, in2, operation) {
    var a = (Math.floor(in1) * 9) + ((in1 * 100) % 10);
    var b = (Math.floor(in2) * 9) + ((in2 * 100) % 10);
    if (operation == '*') {
        if (in1 % 1 != 0) a = a * in2;
        else a = b * in1;
        a = (a / 9) * 100;
        a = Math.floor(a);
        a = a / 100;
        return a;
    }
    else if (operation == "+") {
        a = a + b;
        a = (a / 9) * 100;
        a = Math.floor(a);
        a = a / 100;
        return a;
    }
    else if (operation == "-") {
        a = a - b;
        a = (a / 9) * 100;
        a = Math.floor(a);
        a = a / 100;
        return a;
    }
    else if (operation == "/") {
        a = Math.floor(in1 / in2)
        return a;
    }
}

function AddKeys(value) {

    if (!value) value = document.getElementById("keys_input").value;
    var maxValue = InvMetalValue(inv).key;
    console.log(maxValue)
    if (value <= maxValue) {
        manageItemsInTrade(who, createStackByClassID(101785959, value, inv, reverse), 'add');
        document.getElementById("keys_input").value = "";
    }
    else alert("Not enough keys");
}

function AddMetal(value) {
    console.log(value)
    if (!value) value = document.getElementById("metal_input").value;
    var inScrap = 0;
    var ref = Math.floor(value);
    inScrap += ref * 9;
    inScrap += Math.ceil((((value * 1000) - ref * 1000)) % 100) / 10
    var max_ref = InvMetalValue(inv).ref;
    var max_rec = InvMetalValue(inv).rec;
    var max_scrap = InvMetalValue(inv).scrap;
    console.log(max_ref, max_rec, max_scrap)
    var addRef = Math.min(ref, max_ref);
    for (var i = 0; i < addRef; i++) {
        inScrap -= 9;
    }

    var rec = Math.floor(inScrap / 3);
    var addRec = Math.min(rec, max_rec);
    for (var i = 0; i < addRec; i++) {
        inScrap -= 3;
    }

    var addScrap = Math.min(inScrap, max_scrap);
    for (var i = 0; i < addScrap; i++) {
        inScrap -= 1;
    }
    if (inScrap == 0) {
        if (addRef != 0) manageItemsInTrade(who, createStackByClassID(2674, addRef, inv, reverse), 'add');
        if (addRec != 0) manageItemsInTrade(who, createStackByClassID(5564, addRec, inv, reverse), 'add');
        if (addScrap != 0) manageItemsInTrade(who, createStackByClassID(2675, addScrap, inv, reverse), 'add');
        document.getElementById("metal_input").value = "";
    }

    else alert("Not enough metal");
    Inv_Who();
}


function ToTrade(elItem, amount) {
    Inv_Who(elItem);
    if (amount > 1) manageItemsInTrade(who, createStackByClassID(elItem.rgItem.classid, amount, inv, false), 'add')
    else { manageItemsInTrade(who, [elItem.rgItem], 'add') }
    elItem.children[1].style.display = "none";
    elItem.children[1].lastChild.value = 1;
}


function ToInventory(elItem, amount) {
    Inv_Who(elItem);
    elItem.children[1].style.display = "none";
    if (amount > 1) manageItemsInTrade(who, createStackByClassID(elItem.rgItem.classid, amount, who.assets, false), 'rm')
    else { manageItemsInTrade(who, [itemToAsset(elItem.rgItem)], 'rm') }
    elItem.children[1].lastChild.value = 1;
}

function updateTrade() {
    MyInv = MyInv_Full.slice();
    TheirInv = TheirInv_Full.slice();

    g_rgCurrentTradeStatus.me.assets.forEach(item => {
        var idx = MyInv.findIndex(x => x.id == item.assetid);
        item.classid = MyInv[idx].classid;
        MyInv.splice(idx, 1);

    })

    g_rgCurrentTradeStatus.them.assets.forEach(item => {
        var idx = TheirInv.findIndex(x => x.id == item.assetid);
        item.classid = TheirInv[idx].classid;
        TheirInv.splice(idx, 1);

    })
    MyInv.sort(function (a, b) { return a.pos - b.pos });
    TheirInv.sort(function (a, b) { return a.pos - b.pos });
    //RedrawCurrentTradeStatus();
}

function createStackByClassID(classid, amount, inv, reverse) {
    var assets = [];
    classid = "" + classid + "";
    if (reverse) inv.reverse();
    var found = 0;
    for (i = 0; found < amount; i++) {
        if (inv[i].classid == classid) { assets.push(inv[i]); found++; }
    }
    if (reverse) inv.reverse();
    return assets;
}

function itemToAsset(item) {
    var asset = {
        "appid": 440,
        "contextid": "2",
        "amount": 1,
        "assetid": item.id
    }
    return asset;
}

var delayed = function (assets) {
    for (i = 0; i < 10; i++) {
        assets.forEach(asset => {
            var idx = who.assets.findIndex(x => x.assetid == asset.assetid);
            who.assets.splice(idx, 1);
        })
    }
    updateTrade();
}

function manageItemsInTrade(who, assets, operation) {
    if (operation == "add") {
        assets.forEach(asset => {
            who.assets.push(itemToAsset(asset));
        })
        updateTrade();
        RedrawCurrentTradeStatus();
    }
    else if (operation == "rm") {
        var count = 0;
        for (i = 0; i < assets.length; i++) {
            var idx = who.assets.findIndex(x => x.assetid == assets[i].assetid);
            who.assets.splice(idx, 1);
            count++;
            if (count == 10) { count = 0; updateTrade(); RefreshTradeStatus(g_rgCurrentTradeStatus, false); }
        }
        updateTrade();
        RedrawCurrentTradeStatus();
        setTimeout(FixAfterClear, 10)
    }

}

function InvMetalValue(inv) {
    var scrap = [0, 0];
    var rec = [0, 0];
    var ref = [0, 0];
    var keys = [0, 0];
    inv.forEach(item => {
        if (item.classid == 2675) { scrap[0] += 1; scrap[1] += 1; }
        if (item.classid == 5564) { rec[0] += 1; rec[1] += 1; }
        if (item.classid == 2674) { ref[0] += 1; ref[1] += 1; }
        if (item.classid == 101785959) { keys[0] += 1; keys[1] += 1; }

        if (scrap[0] == 3) { rec[0] += 1; scrap[0] = 0 };
        if (rec[0] == 3) { ref[0] += 1; rec[0] = 0 };
    })
    return metal = {
        value: (ref[0] * 100 + (rec[0] * 33) + (scrap[0] * 11)) / 100,
        scrap: scrap[1],
        rec: rec[1],
        ref: ref[1],
        key: keys[1]
    }
}

function UpdateMetalValue() {
    Inv_Who()
    document.getElementById("metal_input").placeholder = InvMetalValue(inv).value;
    document.getElementById("metal_input").max = document.getElementById("metal_input").placeholder
    document.getElementById("keys_input").placeholder = InvMetalValue(inv).key;
    document.getElementById("keys_input").max = document.getElementById("keys_input").placeholder;
    document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[0].innerText = InvMetalValue(inv).ref;
    document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[1].innerText = InvMetalValue(inv).rec;
    document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[2].innerText = InvMetalValue(inv).scrap;
}



var trade_accepted = false;

document.getElementById("accept_button").addEventListener('contextmenu', function (e) {
    AcceptTrade(true);
    e.preventDefault();
}, false);

document.getElementById("accept_button").addEventListener('click', function (e) {
    AcceptTrade(false)
    e.preventDefault();
}, false);


function AcceptTrade(send) {
    if (!trade_accepted) {
        document.getElementById("accept_button").style.backgroundColor = "#364600";
        document.getElementById("accept_button").style.borderColor = "#88af00";
        document.getElementById("check_sign").style.backgroundColor = "#88af00";
        ToggleReady(true);
        if (send) ConfirmTradeOffer();
    }
    else if (trade_accepted) {
        if (send) { ConfirmTradeOffer(); return true; }
        document.getElementById("accept_button").style.backgroundColor = "rgb(19, 19, 19)";
        document.getElementById("accept_button").style.borderColor = "#3a3a3a";
        document.getElementById("check_sign").style.backgroundColor = "#3a3a3a";
        ToggleReady(false);
    }
    trade_accepted = !trade_accepted;
}

function check_amount(elItem) {
    Inv_Who(elItem)
    var amount = 0;
    if (BIsInTradeSlot(elItem))
        who.assets.forEach(asset => { if (asset.classid == elItem.rgItem.classid) amount++; });
    else
        inv.forEach(item => { if (item.classid == elItem.rgItem.classid) amount++; });
    return amount;
}

var check_maxInput = function (elInput) { if (Number(elInput.value) > Number(elInput.max)) { elInput.value = elInput.max; } }
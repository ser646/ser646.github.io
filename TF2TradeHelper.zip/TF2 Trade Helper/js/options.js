var save_options = function () {
  var steamid = document.getElementsByClassName("steamid_input")[0].value;
  var reversed_adding = document.getElementById("reversed_adding_checkbox").checked;
  var apikey = document.getElementById("apikey_input").value;
  chrome.storage.sync.set({
    reversed_adding: reversed_adding,
    steamid: steamid,
    apikey: apikey
  }, function () {
    console.log("Saved");
  });
}

function restore_options() {
  chrome.storage.sync.get({
    reversed_adding: false,
    steamid: "",
    apikey: ""
  }, function (items) {
    document.getElementsByClassName("steamid_input")[0].value = items.steamid;
    document.getElementById("reversed_adding_checkbox").checked = items.reversed_adding;
    document.getElementById("apikey_input").value = items.apikey;
  });
}

var checkSteamId = function () {
  var steamid = this.value;
  document.getElementById("steamid_error").style.display = "none";
  steamid = "" + steamid + "";
  if (steamid != '') {
    if (steamid.slice(0, 7) != '7656119' || steamid.length != 17) { document.getElementById("steamid_error").style.display = "block"; return false; }
    else if (steamid.slice(0, 7) == '7656119' || steamid.length == 17) { save_options(); return true; }
  }
  else save_options();
}

document.getElementsByClassName("steamid_input")[0].addEventListener('change', checkSteamId);
document.getElementById("apikey_input").addEventListener('change', save_options);
document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById("reversed_adding_checkbox").onclick = save_options;
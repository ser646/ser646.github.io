var ref_src = chrome.extension.getURL('images/ref_icon.png');
var rec_src = chrome.extension.getURL('images/rec_icon.png');
var scrap_src = chrome.extension.getURL('images/scrap_icon.png');
var key_src = chrome.extension.getURL('images/key_icon.png');

var b1 = $("#b_symbol");
var b2 = $("#b_equals");
var value = $("#in_equals");
b1.click(b1_clicked);
b2.click(b2_clicked);

var state = '*';
function b1_clicked() {
	if (state == '*') { b1.html("+"); state = "+"; }
	else if (state == "+") { b1.html("-"); state = "-"; }
	else if (state == "-") { b1.html("/"); state = '/'; }
	else if (state == "/") { b1.html("&times"); state = '*'; }
}

function b2_clicked() {
	var in1 = Number($('#in1').val());
	var in2 = Number($('#in2').val());
	var a = (Math.floor(in1) * 9) + ((in1 * 100) % 10);
	var b = (Math.floor(in2) * 9) + ((in2 * 100) % 10);

	if (state == '*') {
		if (in1 % 1 != 0) a = a * in2;
		else a = b * in1;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		value.val(a);
	}
	else if (state == "+") {
		a = a + b;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		value.val(a);
	}
	else if (state == "-") {
		a = a - b;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		value.val(a);
	}
	else if (state == "/") {
		a = Math.floor(in1 / in2)
		value.val(a);
	}
	value.css("borderColor", "#c0c0c0");
}

function setIcons() {
	$('.img')[0].style = "background-image: url(" + key_src + ")"
	$('.img')[1].style = "background-image: url(" + ref_src + ")"
	$('.img')[2].style = "background-image: url(" + rec_src + ")"
	$('.img')[3].style = "background-image: url(" + scrap_src + ")"
}

function createInv() {
	ele = $('.inventory').eq(0);
	$('<div class="inventory container-column"></div>').insertBefore(ele);
	$('<div id="separator"></div>').insertBefore(ele);
	ele = '<div class="item-container"><div class="item-amount">0</div><div class="img ")></div></div>'
	$('.inventory').eq(0).append(ele);
	$('.inventory').eq(0).append(ele);
	$('.inventory').eq(0).append(ele);
	$('.inventory').eq(0).append(ele);
	setIcons();
}

function setInv(steamid) {
	var url = "http://api.steampowered.com/IEconItems_440/GetPlayerItems/v0001/?key=" + apikey + "&steamid=" + steamid + "";
	var inv
	$.get(url, function (data, success) {
		inv = data.result.items;
		var scrap = 0;
		var rec = 0;
		var ref = 0;
		var keys = 0;
		for (var item in inv) {
			if (!inv[item].flag_cannot_trade) {
				if (inv[item].defindex == 5000 && inv[item].quality == 6) { scrap += 1; }
				if (inv[item].defindex == 5001 && inv[item].quality == 6) { rec += 1; }
				if (inv[item].defindex == 5002 && inv[item].quality == 6) { ref += 1; }
				if (inv[item].defindex == 5021 && inv[item].quality == 6) { keys += 1; }
			}
		}
		$('.item-amount').eq(0).text("" + keys + "");
		$('.item-amount').eq(1).text("" + ref + "");
		$('.item-amount').eq(2).text("" + rec + "");
		$('.item-amount').eq(3).text("" + scrap + "");
	});
}

/*
function getSteamIdCookie() {
	chrome.cookies.get({ "url": 'https://steamcommunity.com', "name": 'steamLogin' }, function (cookie) {
		var steamid = "" + cookie.value + "";
		steamid = steamid.slice(0, 17)
		setInv(steamid);
	}
	);
}*/

var apikey = "";

function restore_options() {
	chrome.storage.sync.get({
		steamid: false,
		apikey: false
	}, function (items) {
		apikey = items.apikey;
		if (items.steamid) setInv(items.steamid);
		else { document.getElementById("svg").style.display = "block"; $("#error").css("display", "block"); }
		//else if (!items.steamid) getSteamIdCookie();
	});
}
$("#error").click(function () { chrome.runtime.openOptionsPage(); })
$("#in_equals").click(function () { this.select(); })

$("#in2").on("keyup", function (event) {
	event.preventDefault();
	if (event.keyCode === 13) {
		b2.click();
	}
});

restore_options();
setIcons();

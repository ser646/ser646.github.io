function calc(in1, in2, type) {

	var a = (Math.floor(in1) * 9) + ((in1 * 100) % 10);
	var b = (Math.floor(in2) * 9) + ((in2 * 100) % 10);
	if (type == '*') {
		if (in1 % 1 != 0) a = a * in2;
		else a = b * in1;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		return a;
	}
	else if (type == "+") {
		a = a + b;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		return a;
	}
	else if (type == "-") {
		a = a - b;
		a = (a / 9) * 100;
		a = Math.floor(a);
		a = a / 100;
		return a;
	}
	else if (type == "/") {
		a = Math.floor(in1 / in2)
		return a;
	}
}

//Fix after moving items to fast
function int_round4(num) {
	return Math.ceil(num / 4) * 4;
}
function RemoveSlots(slots, hasItem) {
	var s = Math.ceil(slots.length / 4) * 4;
	var h = Math.ceil(int_round4(hasItem.length) / 4) * 4;
	if (h >= 2) {
		for (var i = 0; i < (s - h); i++) {
			slots[h].remove();
		}
	}
	else {
		for (var j = 0; j < (s / 4); j++) {
			for (var i = 0; i < s - 8; i++) {
				if (slots[8]) slots[8].remove();
			}
		}
	}
}
function FixAfterClear() {
	var slots = document.getElementById("trade_yours").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot");
	var hasItem = document.getElementById("trade_yours").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot has_item");
	RemoveSlots(slots, hasItem);
	var slots = document.getElementById("trade_theirs").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot");
	var hasItem = document.getElementById("trade_theirs").getElementsByClassName("trade_item_box")[0].getElementsByClassName("itemHolder trade_slot has_item");
	RemoveSlots(slots, hasItem);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
var Add = 'Add'
var Rm = 'Rm'

function CreateAmountElement(type) {
	var item_holders
	if (type == 'Add') item_holders = document.getElementById("inventories").getElementsByClassName("itemHolder")
	else if (type == 'Rm') item_holders = document.getElementById("trade_area").getElementsByClassName("itemHolder")

	for (i = 0; i < item_holders.length; i++) {
		var div = document.createElement("div")
		if (item_holders[i].getElementsByClassName("amount_element")[0] == null) {
			if (type == 'Add') var sign = '+';
			if (type == 'Rm') var sign = '-';
			div.setAttribute("class", "amount_element")
			div.setAttribute("style", "position: absolute; top: 0px; z-index: 21; display: none;")
			item_holders[i].setAttribute("onmouseenter", 'display_amount(this,"block")');
			item_holders[i].setAttribute("onmouseleave", 'display_amount(this,"none")');
			div.innerHTML += '<button class="amount_button" onclick="Amount(this, ' + type + ')">' + sign + '</button><input type="number" value = "1" oninput="check_value(this)"class="amount_text">'
			item_holders[i].appendChild(div)
		}
	}
}

function Amount(ele, operation) {
	var amount = ele.parentElement.getElementsByClassName("amount_text")[0].value
	if (amount == 1) {
		var item = ele.parentElement.parentElement.getElementsByClassName("item app440 context2")[0]
		if (operation == 'Add') MoveItemToTrade(item);
		else if (operation == 'Rm') MoveItemToInventory(item)
		ele.parentElement.parentElement.getElementsByClassName("amount_element")[0].style.display = "none";
		return 0;
	}
	AddAmount(ele.parentElement, operation, amount)
}

function AddAmount(ele, operation, amount) {
	var inventory = ele.parentElement.parentElement.parentElement.getElementsByClassName("item");
	var app_data = ele.parentElement.getElementsByClassName("item app440 context2")[0].rgItem.app_data
	var items = [];
	for (i = 0; i < inventory.length; i++) {
		if (inventory[i].rgItem.app_data.def_index == app_data.def_index && inventory[i].rgItem.app_data.quality == app_data.quality) items.push(inventory[i]);
	}
	items = Array.from(items);
	if (operation == 'Add') {
		if (reversed_adding) items = items.reverse();
		if (dynamic_item_transfer) {
			function s(i) {
				setTimeout(function () {
					MoveItemToTrade(items[i])
				}, 1 * i);
			}
			for (var i = 0; i < amount; i++) {
				s(i);
			};
		}
		else if (!dynamic_item_transfer) {
			for (var i = 0; i < amount; i++) {
				MoveItemToTrade(items[i]);
			}
		}
	}
	else if (operation == 'Rm') {
		items = items.reverse();
		if (dynamic_item_transfer) {
			function s(i) {
				setTimeout(function () {
					MoveItemToInventory(items[i]);
					FixAfterClear();
				}, 1 * i);
			}
			for (var i = 0; i < amount; i++) {
				s(i);
			};
		}
		else if (!dynamic_item_transfer) {
			for (var i = 0; i < amount; i++) {
				MoveItemToInventory(items[i]);
				FixAfterClear();
			}
		}
	}
}

function max_value(ele) {
	var max = 1
	var items = ele.parentElement.parentElement.parentElement.getElementsByClassName("item")
	for (i = 0; i < items.length; i++) {
		if (items[i].rgItem.app_data.def_index == ele.rgItem.app_data.def_index && items[i].rgItem.app_data.quality == ele.rgItem.app_data.quality) max++
	}
	max -= 1
	return max;
}

function check_value(ele) {
	var element = ele.parentElement.parentElement.getElementsByClassName("item app440 context2")[0]
	var max = max_value(element)
	var amount_ele = ele.parentElement.getElementsByClassName("amount_text")[0]
	if (amount_ele.value > max) amount_ele.value = max
	else if (amount_ele.value < 1) amount_ele.value = 1
}

function display_amount(ele, display) {
	var element = ele.getElementsByClassName("item app440 context2")[0]
	if (element != null) {
		var max = max_value(element)
		ele.getElementsByClassName("amount_text")[0].setAttribute("max", max)
		ele.getElementsByClassName("amount_text")[0].setAttribute("min", 1)
		ele.getElementsByClassName("amount_element")[0].style.display = "" + display + "";
		if (display == "none") ele.getElementsByClassName("amount_text")[0].value = "1"
	}
	else if (element == null) {
		ele.getElementsByClassName("amount_element")[0].style.display = "none";
		ele.getElementsByClassName("amount_text")[0].value = "1"
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////////////
function AddKeys() {
	amount = document.getElementById("keys_input").value;
	var found = [0, 0];
	var inv = g_ActiveInventory.elInventory.getElementsByClassName("item app440 context2");
	for (var i = 0; i < inv.length; i++) {
		if (inv[i].rgItem.app_data.def_index == "5021" && inv[i].rgItem.app_data.quality == "6") { found[0]++; if (found[0] == 1) found[1] = inv[i]; }
	}
	if (amount <= found[0]) {
		AddAmount(found[1], Add, amount);
		document.getElementById("keys_input").value = "";
	}
	else alert("Insufficient amount of keys");
}

function AddMetal(value) {
	var value = document.getElementById("metal_input").value;
	value = Number(value);
	var inScrap = 0;
	var ref = Math.floor(value);
	inScrap += ref * 9;
	inScrap += Math.ceil((((value * 1000) - ref * 1000)) % 100) / 10
	var max_ref = max_metal('ref');
	var max_rec = max_metal('rec');
	var max_scrap = max_metal('scrap');
	var addRef = Math.min(ref, max_ref);
	for (var i = 0; i < addRef; i++) {
		inScrap -= 9;
	}
	var rec = Math.floor(inScrap / 3);
	var addRec = Math.min(rec, max_rec);
	for (var i = 0; i < addRec; i++) {
		inScrap -= 3;
	}
	var addScrap = Math.min(inScrap, max_scrap);
	for (var i = 0; i < addScrap; i++) {
		inScrap -= 1;
	}
	if (inScrap == 0) {
		var inv = g_ActiveInventory.elInventory.getElementsByClassName("item app440 context2");
		var ref_ele, rec_ele, scrap_ele;

		for (var i = 0; i < inv.length; i++) {
			if (inv[i].rgItem.app_data.def_index == "5000" && inv[i].rgItem.app_data.quality == "6") { scrap_ele = inv[i]; }
			if (inv[i].rgItem.app_data.def_index == "5001" && inv[i].rgItem.app_data.quality == "6") { rec_ele = inv[i]; }
			if (inv[i].rgItem.app_data.def_index == "5002" && inv[i].rgItem.app_data.quality == "6") { ref_ele = inv[i]; }
		}

		if (addRef != 0) AddAmount(ref_ele, Add, addRef);
		if (addRec != 0) AddAmount(rec_ele, Add, addRec);
		if (addScrap != 0) AddAmount(scrap_ele, Add, addScrap);
		document.getElementById("metal_input").value = "";
	}
	else alert("Insufficient amount of metal");
}

document.getElementById("add_keys").setAttribute("onclick", "AddKeys()");
document.getElementById("add_metal").setAttribute("onclick", "AddMetal()");

function max_metal(type) {
	var inv = g_ActiveInventory.elInventory.getElementsByClassName("item app440 context2");
	var value = 0;
	var scrap = [0, 0];
	var rec = [0, 0];
	var ref = [0, 0];
	var keys = [0, 0];
	for (i = 0; i < inv.length; i++) {
		if (inv[i].rgItem.app_data.def_index == "5000" && inv[i].rgItem.app_data.quality == "6") { scrap[0] += 1; scrap[1] += 1; }
		if (inv[i].rgItem.app_data.def_index == "5001" && inv[i].rgItem.app_data.quality == "6") { rec[0] += 1; rec[1] += 1; }
		if (inv[i].rgItem.app_data.def_index == "5002" && inv[i].rgItem.app_data.quality == "6") { ref[0] += 1; ref[1] += 1; }
		if (inv[i].rgItem.app_data.def_index == "5021" && inv[i].rgItem.app_data.quality == "6") { keys[0] += 1; keys[1] += 1; }

		if (scrap[0] == 3) { rec[0] += 1; scrap[0] = 0 };
		if (rec[0] == 3) { ref[0] += 1; rec[0] = 0 };
	}
	if (type == 'all') return value = (ref[0] * 100 + (rec[0] * 33) + (scrap[0] * 11)) / 100;
	else if (type == 'scrap') return scrap[1];
	else if (type == 'rec') return rec[1];
	else if (type == 'ref') return ref[1];
	else if (type == 'keys') return keys[1];
}

function UpdateMetalValue() {
	document.getElementById("metal_input").placeholder = max_metal('all');
	document.getElementById("keys_input").placeholder = max_metal('keys');
	document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[0].innerText = max_metal('ref');
	document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[1].innerText = max_metal('rec');
	document.getElementById("total_metal_amount").getElementsByClassName("currency_value")[2].innerText = max_metal('scrap');
}

var trade_accepted = false;

document.getElementById("accept_button").addEventListener('contextmenu', function (e) {
	AcceptTrade(true);
	e.preventDefault();
}, false);

document.getElementById("accept_button").addEventListener('click', function (e) {
	AcceptTrade(false)
	e.preventDefault();
}, false);

function AcceptTrade(send) {
	if (!trade_accepted) {
		document.getElementById("accept_button").style.backgroundColor = "#364600";
		document.getElementById("accept_button").style.borderColor = "#88af00";
		document.getElementById("check_sign").style.backgroundColor = "#88af00";
		ToggleReady(true);
		if (send) ConfirmTradeOffer();
	}
	else if (trade_accepted) {
		if (send) { ConfirmTradeOffer(); return true; }
		document.getElementById("accept_button").style.backgroundColor = "rgb(19, 19, 19)";
		document.getElementById("accept_button").style.borderColor = "#3a3a3a";
		document.getElementById("check_sign").style.backgroundColor = "#3a3a3a";
		ToggleReady(false);
	}
	trade_accepted = !trade_accepted;
}

//Observers
var select_button = document.getElementsByClassName("inventory_user_tab")
select_button[0].setAttribute("onclick", 'CreateAmountElement("Add");UpdateMetalValue()');
select_button[1].setAttribute("onclick", 'CreateAmountElement("Rm");UpdateMetalValue()');

function InventoryMutation() { CreateAmountElement('Add'); UpdateMetalValue() }
function TradeMutation() { CreateAmountElement('Rm'); if (trade_accepted && !UserYou.bReady) AcceptTrade(false); }

var inventory_observer = new MutationObserver(InventoryMutation)
var trade_observer = new MutationObserver(TradeMutation)

var observer_cfg = { subtree: true, childList: true }
inventory_observer.observe(document.getElementById('inventories'), observer_cfg)
trade_observer.observe(document.getElementById('trade_area'), observer_cfg)

CreateAmountElement('Add')
var dynamic_item_transfer = true;
var reversed_adding = false;


//Receive messages
window.addEventListener("ToInjected", function (evt) {
	dynamic_item_transfer = evt.detail[0];
	reversed_adding = evt.detail[1];
	console.log("Received: ", evt.detail);
}, false);

//Send messages

function SendMessage(data) {
	var message = { data };
	console.log("Sent:", message);
	var event = new CustomEvent("FromInjected", { detail: message });
	window.dispatchEvent(event);
}
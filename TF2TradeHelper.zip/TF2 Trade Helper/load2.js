//Inject script to page

var s = document.createElement('script');
s.src = chrome.extension.getURL('steam_profile_script.js');
(document.head || document.documentElement).appendChild(s);

var ref_src = chrome.extension.getURL('ref_icon.png');
var bptf_src = chrome.extension.getURL('bptf_icon.png');

var parent = document.getElementsByClassName("persona_name")[0]
var ele = document.createElement("div");
ele.id = "bptf";
ele.style = "float: right;width: 40px;height: 40px;background-size: 40px;background-repeat: no-repeat;background-position: center;margin-right: 20px;background-image: url("+bptf_src+")";
parent.appendChild(ele);

parent = ele;
var link = document.createElement("a");
link.style = "width: 40px;height: 40px;display: block;";
link.target= "_blank";
parent.appendChild(link);

window.addEventListener("FromInjected", function (evt) {
	link.href = "https://backpack.tf/profiles/"+evt.detail.data+"";
}, false);



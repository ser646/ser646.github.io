//Images-src
var ref_src = chrome.extension.getURL('ref_icon.png');
var rec_src = chrome.extension.getURL('rec_icon.png');
var scrap_src = chrome.extension.getURL('scrap_icon.png');
var key_src = chrome.extension.getURL('key_icon.png');

//Creating addon ele
var ele = document.createElement("div");
ele.id = "addon_div";
document.getElementById("nonresponsivetrade_itemfilters").insertBefore(ele, document.getElementsByClassName("filter_ctn")[0]);
var parent = ele;


//Creating add_value_ele

	//Keys div
	ele = document.createElement("div");
	ele.id = "keys_div";
	ele.style = "float: left;";
	parent.appendChild(ele);
	parent = ele;

		ele = document.createElement("div");
		ele.id = "add_keys";
		ele.className = "add_value_button";
		ele.style = "float:left; background-image: url(" + key_src + ")";
		parent.appendChild(ele);

		ele = document.createElement("input");
		ele.type = "number";
		ele.id = "keys_input";
		ele.className = "input_value";
		ele.style = "float:right; width: 31px";
		ele.placeholder = "Max";
		parent.appendChild(ele);

	//Metal div
	parent = document.getElementById("addon_div");
	ele = document.createElement("div");
	ele.id = "metal_div";
	ele.style = "float: left";
	parent.appendChild(ele);
	parent = ele;

		ele = document.createElement("div");
		ele.id = "add_metal";
		ele.className = "add_value_button";
		ele.style = "float:left;background-image: url(" + ref_src + ")";
		parent.appendChild(ele);

		ele = document.createElement("input");
		ele.type = "number";
		ele.id = "metal_input";
		ele.className = "input_value";
		ele.style = "float:right";
		ele.placeholder = "Max";
		parent.appendChild(ele);

//Creating total_metal_amount
parent = document.getElementById("addon_div");
ele = document.createElement("div");
ele.id = "total_metal_amount";
parent.appendChild(ele);
parent = ele;

	ele = document.createElement("div");
	ele.className = "currency_div";
	parent.appendChild(ele);
	parent = ele;

		ele = document.createElement("div");
		ele.className = "currency_value";
		parent.appendChild(ele);

		ele = document.createElement("div");
		ele.className = "currency_image";
		ele.style = "background-image: url(" + ref_src + ")";
		parent.appendChild(ele);

	parent = document.getElementById("total_metal_amount");
	ele = document.createElement("div");
	ele.className = "currency_div";
	parent.appendChild(ele);
	parent = ele;

		ele = document.createElement("div");
		ele.className = "currency_value";
		parent.appendChild(ele);

		ele = document.createElement("div");
		ele.className = "currency_image";
		ele.style = "background-image: url(" + rec_src + ")";
		parent.appendChild(ele);

	parent = document.getElementById("total_metal_amount");
	ele = document.createElement("div");
	ele.className = "currency_div";
	ele.style = "margin-right: 0px";
	parent.appendChild(ele);
	parent = ele;

		ele = document.createElement("div");
		ele.className = "currency_value";
		parent.appendChild(ele);

		ele = document.createElement("div");
		ele.className = "currency_image";
		ele.style = "background-image: url(" + scrap_src + ")";
		parent.appendChild(ele);

parent = document.getElementById("addon_div");
ele = document.createElement("div");
ele.id = "accept_button";
ele.title = "LMB to accept | RMB to accept & send"
parent.appendChild(ele);
parent = ele;

	ele = document.createElement("div");
	ele.id = "check_sign";
	parent.appendChild(ele);

//Inject script to page
var s = document.createElement('script');
s.src = chrome.extension.getURL('script.js');

s.onload = function () {
	var img = document.createElement("img");
	restore_options();
};

(document.head || document.documentElement).appendChild(s);

//Restore options
var dynamic_item_transfer = false;
var reversed_adding = false;

function restore_options() {
	chrome.storage.sync.get({
		dtf: true,
		reversed_adding: false
	}, function (items) {
		dynamic_item_transfer = items.dtf;
		reversed_adding = items.reversed_adding;
		SendMessage();
	});
}

//Create communication hole
function SendMessage() {
	var message = [dynamic_item_transfer, reversed_adding]
	console.log("Sent:", message);
	var event = new CustomEvent("ToInjected", { detail: message });
	window.dispatchEvent(event);
}

//Receive data
window.addEventListener("FromInjected", function (evt) {
	console.log("Received: ", evt.detail);
}, false);


